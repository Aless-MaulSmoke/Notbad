#include "notbad.h"
#include <commctrl.h>
#include <richedit.h>

static LPCWSTR g_pszRichEditClass = NULL;
static HMODULE g_hRichEditLib = NULL;

static LPCWSTR GetRichEditClass(void)
{
    if (g_pszRichEditClass != NULL)
        return g_pszRichEditClass;

    g_hRichEditLib = LoadLibraryW(L"Msftedit.dll");
    if (g_hRichEditLib != NULL)
    {
        g_pszRichEditClass = L"RICHEDIT50W";
        return g_pszRichEditClass;
    }

    g_hRichEditLib = LoadLibraryW(L"Riched20.dll");
    g_pszRichEditClass = L"RichEdit20W";
    return g_pszRichEditClass;
}

static LRESULT CALLBACK RichEditSubclassProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam,
                                             UINT_PTR uIdSubclass, DWORD_PTR dwRefData)
{
    LRESULT result;

    (void)uIdSubclass;
    (void)dwRefData;

    // O clique que reativa uma janela inativa nao pode ser descartado pelo
    // RichEdit; MA_ACTIVATE garante que o botao chegue ao controle e que o
    // caret seja posicionado no ponto clicado logo no primeiro clique.
    if (msg == WM_MOUSEACTIVATE)
        return MA_ACTIVATE;

    if (msg == WM_LBUTTONDOWN)
    {
        POINT pt = { (short)LOWORD(lParam), (short)HIWORD(lParam) };

        SetFocus(hWnd);
        result = DefSubclassProc(hWnd, msg, wParam, lParam);

        if ((GetKeyState(VK_SHIFT) & 0x8000) == 0)
            EditorPlaceCaretAtPoint(hWnd, pt);

        return result;
    }

    if (msg == WM_KEYDOWN && EditorHandleKeyDown(hWnd, wParam))
        return 0;

    result = DefSubclassProc(hWnd, msg, wParam, lParam);

    if (msg == WM_SETFOCUS)
        EditorPlaceCaretAtClick(hWnd);

    if (msg == WM_KEYUP || msg == WM_LBUTTONUP)
    {
        if (DocFromEdit(hWnd) == g_pActiveDoc)
        {
            UpdateStatusBar();
            InvalidateLineNumbers();
        }
    }

    if (msg == WM_VSCROLL || msg == WM_MOUSEWHEEL)
        InvalidateLineNumbers();

    return result;
}

static HWND CreateRichEdit(Document* pDoc)
{
    DWORD style = WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL |
                  ES_MULTILINE | ES_AUTOVSCROLL | ES_AUTOHSCROLL |
                  ES_NOHIDESEL | ES_WANTRETURN;

    HWND hEdit = CreateWindowExW(WS_EX_CLIENTEDGE, GetRichEditClass(), L"",
                                 style, 0, 0, 0, 0,
                                 g_hWndMain, (HMENU)(INT_PTR)ID_EDIT,
                                 g_hInstance, NULL);
    if (hEdit == NULL)
        return NULL;

    EditorApplyWordWrapTo(hEdit, g_settings.wordWrap);
    SendMessageW(hEdit, EM_SETEDITSTYLE, SES_EXTENDBACKCOLOR, SES_EXTENDBACKCOLOR);

    SendMessageW(hEdit, EM_SETLIMITTEXT, MAX_EDIT_BUFFER, 0);
    SendMessageW(hEdit, EM_SETUNDOLIMIT, 1000, 0);
    SendMessageW(hEdit, EM_SETEVENTMASK, 0, ENM_CHANGE | ENM_SELCHANGE | ENM_SCROLL);
    SetWindowSubclass(hEdit, RichEditSubclassProc, 1, (DWORD_PTR)pDoc);

    if (g_hFont != NULL)
        SendMessageW(hEdit, WM_SETFONT, (WPARAM)g_hFont, TRUE);

    EditorApplyTabWidthTo(hEdit);

    return hEdit;
}

Document* DocActive(void)
{
    return g_pActiveDoc;
}

Document* DocFromEdit(HWND hEdit)
{
    size_t i;

    if (hEdit == NULL)
        return NULL;

    for (i = 0; i < g_documents.size(); ++i)
    {
        if (g_documents[i]->hEdit == hEdit)
            return g_documents[i];
    }

    return NULL;
}

int DocIndexOf(Document* pDoc)
{
    size_t i;

    if (pDoc == NULL)
        return -1;

    for (i = 0; i < g_documents.size(); ++i)
    {
        if (g_documents[i] == pDoc)
            return (int)i;
    }

    return -1;
}

// Menor numero de "Untitled" ainda nao usado por outro documento sem arquivo.
static int DocAllocUntitledNumber(void)
{
    int number;
    size_t i;

    for (number = 1; ; ++number)
    {
        BOOL used = FALSE;

        for (i = 0; i < g_documents.size(); ++i)
        {
            if (!g_documents[i]->bHasPath && g_documents[i]->untitledNum == number)
            {
                used = TRUE;
                break;
            }
        }

        if (!used)
            return number;
    }
}

// Nome exibido do documento: titulo do arquivo, ou "Untitled", "Untitled 2", ...
void DocGetDisplayName(Document* pDoc, LPWSTR lpBuffer, int cchBuffer)
{
    if (lpBuffer == NULL || cchBuffer <= 0)
        return;

    if (pDoc != NULL && pDoc->bHasPath && pDoc->szFileTitle[0] != L'\0')
    {
        StringCchCopyW(lpBuffer, cchBuffer, pDoc->szFileTitle);
        return;
    }

    LoadStringResource(IDS_UNTITLED, lpBuffer, cchBuffer);

    if (pDoc != NULL && pDoc->untitledNum > 1)
    {
        size_t len = lstrlenW(lpBuffer);
        StringCchPrintfW(lpBuffer + len, cchBuffer - len, L" %d", pDoc->untitledNum);
    }
}

void DocUpdateTabTitle(Document* pDoc)
{
    WCHAR szName[MAX_PATH + 24];
    WCHAR szTitle[MAX_PATH];
    TCITEMW item = {};

    if (pDoc == NULL || g_hWndTabs == NULL)
        return;

    int index = DocIndexOf(pDoc);
    if (index < 0)
        return;

    DocGetDisplayName(pDoc, szTitle, ARRAYSIZE(szTitle));

    // O espaco extra a direita do texto reserva a area do botao de fechar
    // desenhado pelo subclass da barra de abas (window.cpp).
    StringCchPrintfW(szName, ARRAYSIZE(szName), L"%s%s%s",
                     SendMessageW(pDoc->hEdit, EM_GETMODIFY, 0, 0) ? L"* " : L"",
                     szTitle, TabGetClosePadding());

    // Se o texto nao mudou, nao reescrever o item: SetItem a cada tecla
    // repinta a aba e contribui para o flicker.
    WCHAR szOld[MAX_PATH + 24] = L"";
    TCITEMW oldItem = {};
    oldItem.mask = TCIF_TEXT;
    oldItem.pszText = szOld;
    oldItem.cchTextMax = ARRAYSIZE(szOld);
    if (TabCtrl_GetItem(g_hWndTabs, index, &oldItem) &&
        lstrcmpW(szOld, szName) == 0)
    {
        return;
    }

    item.mask = TCIF_TEXT;
    item.pszText = szName;
    TabCtrl_SetItem(g_hWndTabs, index, &item);
}

void DocActivate(Document* pDoc)
{
    size_t i;
    int index;

    if (pDoc == NULL)
        return;

    index = DocIndexOf(pDoc);
    if (index < 0)
        return;

    g_pActiveDoc = pDoc;
    g_iActiveDoc = index;
    g_hWndEdit = pDoc->hEdit;

    if (g_hWndTabs != NULL)
    {
        g_bUpdatingTabs = TRUE;
        TabCtrl_SetCurSel(g_hWndTabs, index);
        g_bUpdatingTabs = FALSE;
    }

    for (i = 0; i < g_documents.size(); ++i)
    {
        ShowWindow(g_documents[i]->hEdit, g_documents[i] == pDoc ? SW_SHOW : SW_HIDE);
    }

    LayoutMainWindow();
    EditorApplyTabWidthTo(pDoc->hEdit);
    InvalidateLineNumbers();
    UpdateWindowTitle();
    UpdateStatusBar();
    UpdateEditMenuState(g_hWndMain);
    SetFocus(pDoc->hEdit);
    EditorUpdateCurrentLineHighlight(pDoc->hEdit);
}

Document* DocCreate(void)
{
    Document* pDoc = new Document;
    TCITEMW item = {};
    WCHAR szName[MAX_PATH];

    if (pDoc == NULL)
        return NULL;

    ZeroMemory(pDoc, sizeof(*pDoc));
    pDoc->encoding = ENC_ANSI;
    pDoc->untitledNum = DocAllocUntitledNumber();
    pDoc->hEdit = CreateRichEdit(pDoc);
    if (pDoc->hEdit == NULL)
    {
        delete pDoc;
        return NULL;
    }

    g_documents.push_back(pDoc);

    if (g_hWndTabs != NULL)
    {
        LoadStringResource(IDS_UNTITLED, szName, ARRAYSIZE(szName));
        item.mask = TCIF_TEXT;
        item.pszText = szName;

        g_bUpdatingTabs = TRUE;
        int inserted = TabCtrl_InsertItem(g_hWndTabs, (int)g_documents.size() - 1, &item);
        g_bUpdatingTabs = FALSE;

        if (inserted < 0)
        {
            g_documents.pop_back();
            DestroyWindow(pDoc->hEdit);
            delete pDoc;
            return NULL;
        }
    }

    DocUpdateTabTitle(pDoc);
    DocActivate(pDoc);

    return pDoc;
}

void DocDestroy(Document* pDoc)
{
    BOOL wasActive;
    int index;
    size_t next;

    if (pDoc == NULL)
        return;

    index = DocIndexOf(pDoc);
    if (index < 0)
        return;

    wasActive = (pDoc == g_pActiveDoc);

    if (g_hWndTabs != NULL)
    {
        g_bUpdatingTabs = TRUE;
        TabCtrl_DeleteItem(g_hWndTabs, index);
        g_bUpdatingTabs = FALSE;
    }

    g_documents.erase(g_documents.begin() + index);
    UpdateTreeOpenMarks();

    if (wasActive)
    {
        g_pActiveDoc = NULL;
        g_iActiveDoc = -1;
        g_hWndEdit = NULL;
    }

    EditorClearCurrentLineHighlight(pDoc);
    DestroyWindow(pDoc->hEdit);
    delete pDoc;

    if (wasActive)
    {
        if (!g_documents.empty())
        {
            next = (size_t)index;
            if (next >= g_documents.size())
                next = g_documents.size() - 1;
            DocActivate(g_documents[next]);
        }
        else
        {
            UpdateWindowTitle();
            UpdateStatusBar();
        }
    }
    else
    {
        // Fechar uma aba anterior a ativa desloca o indice do documento ativo.
        // Sem isso, Ctrl+Tab e o item selecionado passam a apontar para outro
        // documento.
        g_iActiveDoc = DocIndexOf(g_pActiveDoc);
        if (g_hWndTabs != NULL && g_iActiveDoc >= 0)
        {
            g_bUpdatingTabs = TRUE;
            TabCtrl_SetCurSel(g_hWndTabs, g_iActiveDoc);
            g_bUpdatingTabs = FALSE;
        }
    }

    InvalidateLineNumbers();
}

void DocDestroyAll(void)
{
    size_t i;

    for (i = 0; i < g_documents.size(); ++i)
    {
        EditorClearCurrentLineHighlight(g_documents[i]);
        if (IsWindow(g_documents[i]->hEdit))
            DestroyWindow(g_documents[i]->hEdit);
        delete g_documents[i];
    }

    g_documents.clear();
    g_pActiveDoc = NULL;
    g_iActiveDoc = -1;
    g_hWndEdit = NULL;
}

BOOL DocLoad(Document* pDoc, LPCWSTR lpFileName)
{
    LPWSTR lpText = NULL;
    TextEncoding encoding = ENC_ANSI;
    DWORD attrs;

    if (pDoc == NULL || lpFileName == NULL || lpFileName[0] == L'\0')
        return FALSE;

    attrs = GetFileAttributesW(lpFileName);
    if (attrs == INVALID_FILE_ATTRIBUTES)
    {
        WCHAR szMessage[512];
        LoadStringResource(IDS_OPEN_FAILED, szMessage, ARRAYSIZE(szMessage));
        MessageBoxW(g_hWndMain, szMessage, NOTBAD_NAME, MB_ICONERROR | MB_OK);
        return FALSE;
    }

    if (!LoadTextFile(lpFileName, &lpText, &encoding))
    {
        WCHAR szMessage[512];
        LoadStringResource(IDS_OPEN_FAILED, szMessage, ARRAYSIZE(szMessage));
        MessageBoxW(g_hWndMain, szMessage, NOTBAD_NAME, MB_ICONERROR | MB_OK);
        return FALSE;
    }

    EditorClearCurrentLineHighlight(pDoc);

    SetWindowTextW(pDoc->hEdit, lpText != NULL ? lpText : L"");
    if (lpText != NULL)
        LocalFree(lpText);

    // Trocar o texto pode redefinir a largura do tab do RichEdit.
    EditorApplyTabWidthTo(pDoc->hEdit);

    StringCchCopyW(pDoc->szFilePath, ARRAYSIZE(pDoc->szFilePath), lpFileName);
    StringCchCopyW(pDoc->szFileTitle, ARRAYSIZE(pDoc->szFileTitle),
                   PathFindFileNameW(lpFileName));

    pDoc->bHasPath = TRUE;
    pDoc->encoding = encoding;
    pDoc->bReadOnly = (attrs & FILE_ATTRIBUTE_READONLY) != 0;

    SendMessageW(pDoc->hEdit, EM_SETREADONLY, pDoc->bReadOnly, 0);
    SendMessageW(pDoc->hEdit, EM_SETMODIFY, FALSE, 0);
    SendMessageW(pDoc->hEdit, EM_EMPTYUNDOBUFFER, 0, 0);

    if (pDoc == g_pActiveDoc)
        EditorUpdateCurrentLineHighlight(pDoc->hEdit);

    DocUpdateTabTitle(pDoc);
    UpdateTreeOpenMarks();

    if (pDoc == g_pActiveDoc)
    {
        InvalidateLineNumbers();
        UpdateWindowTitle();
        UpdateStatusBar();
        UpdateEditMenuState(g_hWndMain);
    }

    return TRUE;
}

BOOL DocLoadCurrent(LPCWSTR lpFileName)
{
    return DocLoad(g_pActiveDoc, lpFileName);
}

BOOL DocSaveFile(Document* pDoc, LPCWSTR lpFileName)
{
    int length;
    LPWSTR lpText;
    BOOL result;

    if (pDoc == NULL || lpFileName == NULL)
        return FALSE;

    length = GetWindowTextLengthW(pDoc->hEdit);
    lpText = (LPWSTR)LocalAlloc(LMEM_ZEROINIT, ((SIZE_T)length + 1) * sizeof(WCHAR));
    if (lpText == NULL)
        return FALSE;

    if (length > 0)
        GetWindowTextW(pDoc->hEdit, lpText, length + 1);

    result = SaveTextFile(lpFileName, lpText, pDoc->encoding);

    LocalFree(lpText);
    return result;
}

static BOOL SaveWithDialog(Document* pDoc)
{
    WCHAR szFile[MAX_FILE_PATH];
    WCHAR szFilter[512];
    WCHAR szText[128];
    WCHAR szAll[128];

    if (pDoc->bHasPath)
        StringCchCopyW(szFile, ARRAYSIZE(szFile), pDoc->szFilePath);
    else
        szFile[0] = L'\0';

    LoadStringResource(IDS_FILTER_TEXT, szText, ARRAYSIZE(szText));
    LoadStringResource(IDS_FILTER_ALL, szAll, ARRAYSIZE(szAll));

    StringCchPrintfW(szFilter, ARRAYSIZE(szFilter),
                     L"%s%c*.txt%c%s%c*.*%c",
                     szText, L'\0', L'\0', szAll, L'\0', L'\0');

    OPENFILENAMEW ofn = {};
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = g_hWndMain;
    ofn.lpstrFilter = szFilter;
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = ARRAYSIZE(szFile);
    ofn.lpstrDefExt = L"txt";
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY | OFN_EXPLORER;

    if (!GetSaveFileNameW(&ofn))
        return FALSE;

    if (DocSaveFile(pDoc, szFile))
    {
        StringCchCopyW(pDoc->szFilePath, ARRAYSIZE(pDoc->szFilePath), szFile);
        StringCchCopyW(pDoc->szFileTitle, ARRAYSIZE(pDoc->szFileTitle),
                       PathFindFileNameW(szFile));
        pDoc->bHasPath = TRUE;
        pDoc->bReadOnly = FALSE;
        SendMessageW(pDoc->hEdit, EM_SETREADONLY, FALSE, 0);
        SendMessageW(pDoc->hEdit, EM_SETMODIFY, FALSE, 0);
        DocUpdateTabTitle(pDoc);
        UpdateWindowTitle();
        UpdateStatusBar();
        UpdateEditMenuState(g_hWndMain);
        return TRUE;
    }

    WCHAR szMessage[512];
    LoadStringResource(IDS_SAVE_FAILED, szMessage, ARRAYSIZE(szMessage));
    MessageBoxW(g_hWndMain, szMessage, NOTBAD_NAME, MB_ICONERROR | MB_OK);
    return FALSE;
}

BOOL DocSave(Document* pDoc, BOOL bSaveAs)
{
    if (pDoc == NULL)
        return FALSE;

    if (pDoc->bReadOnly)
        bSaveAs = TRUE;

    if (!pDoc->bHasPath || bSaveAs)
        return SaveWithDialog(pDoc);

    if (!DocSaveFile(pDoc, pDoc->szFilePath))
    {
        WCHAR szMessage[512];
        LoadStringResource(IDS_SAVE_FAILED, szMessage, ARRAYSIZE(szMessage));
        MessageBoxW(g_hWndMain, szMessage, NOTBAD_NAME, MB_ICONERROR | MB_OK);
        return FALSE;
    }

    SendMessageW(pDoc->hEdit, EM_SETMODIFY, FALSE, 0);
    DocUpdateTabTitle(pDoc);
    UpdateTreeOpenMarks();
    UpdateWindowTitle();
    UpdateStatusBar();
    UpdateEditMenuState(g_hWndMain);
    return TRUE;
}

BOOL DocSaveAll(void)
{
    size_t i;

    for (i = 0; i < g_documents.size(); ++i)
    {
        Document* pDoc = g_documents[i];

        if (!SendMessageW(pDoc->hEdit, EM_GETMODIFY, 0, 0))
            continue;

        if (!DocSave(pDoc, FALSE))
            return FALSE;
    }

    UpdateWindowTitle();
    UpdateStatusBar();
    UpdateEditMenuState(g_hWndMain);
    return TRUE;
}

BOOL DocQuerySaveChanges(Document* pDoc)
{
    WCHAR szPrompt[512];
    WCHAR szName[MAX_PATH];
    WCHAR szMessage[768];
    int result;

    if (pDoc == NULL)
        return TRUE;

    if (!SendMessageW(pDoc->hEdit, EM_GETMODIFY, 0, 0))
        return TRUE;

    DocGetDisplayName(pDoc, szName, ARRAYSIZE(szName));

    LoadStringResource(IDS_SAVE_PROMPT, szPrompt, ARRAYSIZE(szPrompt));
    StringCchPrintfW(szMessage, ARRAYSIZE(szMessage), szPrompt, szName);

    result = MessageBoxW(g_hWndMain, szMessage, NOTBAD_NAME,
                         MB_YESNOCANCEL | MB_ICONWARNING);

    if (result == IDYES)
        return DocSave(pDoc, FALSE);
    if (result == IDNO)
        return TRUE;

    return FALSE;
}

BOOL DocQuerySaveAllChanges(void)
{
    size_t i;

    for (i = 0; i < g_documents.size(); ++i)
    {
        if (!DocQuerySaveChanges(g_documents[i]))
            return FALSE;
    }

    return TRUE;
}

BOOL DocClose(Document* pDoc)
{
    BOOL wasLast;

    if (pDoc == NULL)
        return FALSE;

    if (!DocQuerySaveChanges(pDoc))
        return FALSE;

    wasLast = (g_documents.size() == 1 && g_documents[0] == pDoc);

    DocDestroy(pDoc);

    if (wasLast)
        PostMessageW(g_hWndMain, WM_CLOSE, 0, 0);

    return TRUE;
}

// Move o documento 'from' para a posicao 'to' (reordenar abas).
// As abas so guardam texto, entao basta reordenar a lista e reescrever os
// titulos do intervalo afetado; nenhum item e removido/inserido (sem piscar).
void DocMove(int from, int to)
{
    int count = (int)g_documents.size();
    int lo, hi, i;
    Document* pDoc;

    if (from < 0 || to < 0 || from >= count || to >= count || from == to)
        return;

    pDoc = g_documents[from];
    g_documents.erase(g_documents.begin() + from);
    g_documents.insert(g_documents.begin() + to, pDoc);

    lo = from < to ? from : to;
    hi = from < to ? to : from;
    for (i = lo; i <= hi; ++i)
        DocUpdateTabTitle(g_documents[i]);

    g_iActiveDoc = DocIndexOf(g_pActiveDoc);

    if (g_hWndTabs != NULL && g_iActiveDoc >= 0)
    {
        g_bUpdatingTabs = TRUE;
        TabCtrl_SetCurSel(g_hWndTabs, g_iActiveDoc);
        g_bUpdatingTabs = FALSE;
    }
}

void DocCycle(int direction)
{
    int count = (int)g_documents.size();
    int index;

    if (count < 2)
        return;

    index = g_iActiveDoc + direction;
    if (index < 0)
        index = count - 1;
    else if (index >= count)
        index = 0;

    DocActivate(g_documents[index]);
}
